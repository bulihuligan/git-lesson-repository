Get-Process | Format-Table -Property ID, Name
