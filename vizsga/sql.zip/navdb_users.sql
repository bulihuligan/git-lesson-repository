use [AdoxusWorks]
GO
GRANT SELECT ON [SalesLT].[SalesOrderDetail] TO [NAVdbUser]
GO