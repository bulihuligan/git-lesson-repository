BACKUP DATABASE [NAVBlackList] TO  DISK = N'/backups/NAVBlacklist.bak' WITH DESCRIPTION = N'NAV Blacklist Catalog',
NOFORMAT, NOINIT,  NAME = N'NAVBlacklist-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO
