select E.id, E.premises
from dbo.employees E