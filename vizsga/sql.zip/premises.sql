select distinct E.premises
from dbo.employees E