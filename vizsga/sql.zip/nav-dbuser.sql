USE [AdoxusWorks]
GO
CREATE USER [NAVdbUser] FOR LOGIN [NAVMaster]
GO