select E.id, E.sur_name
from dbo.employees E
where E.working_hours = 'inactive'