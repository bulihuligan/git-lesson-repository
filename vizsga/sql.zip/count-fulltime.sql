select count (*)
from dbo.employees E
where E.working_hours = 'full-time'