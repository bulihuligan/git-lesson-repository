select S.sales_value, S.selling_time
from dbo.sales S