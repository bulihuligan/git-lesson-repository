USE [master]
RESTORE DATABASE [AdventureWorks] 
FROM  DISK = N'/ADOXUS/import/AdventureWorksLT2019.bak' 
WITH  FILE = 1,  MOVE N'AdventureWorksLT2012_Data' TO N'/MSDB/Databases/AdventureWorksLT2012.mdf',  
MOVE N'AdventureWorksLT2012_Log' TO N'/MSDB/translogs/AdventureWorksLT2012_log.ldf',  
NOUNLOAD,  
STATS = 5

GO