USE [NAVBlackList]
GO
CREATE SYNONYM [NAVInvoices].[NAV_Invoice_Customers] FOR [AdoxusWorks].[SalesLT].[SalesOrderDetail]
GO