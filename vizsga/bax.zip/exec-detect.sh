#!/bin/bash

if [-x "$1"]
then echo "$1 fajl letezik es futtathato"
fi
