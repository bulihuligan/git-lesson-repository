#!/bin/bash

get_fslist() {
	mount
}

get_releaseinfo() {
	cat /etc/os-release
}

get_userinfo() {
	user=`id -nu $1 2> /dev/null`
	if [ $? -eq 1 ]
	then
		echo "ismeretlen felhasznalo"
	else
		echo $user
	fi
}

get_swapinfo() {
	cat /proc/meminfo | grep SwapTotal
}

mount get_releaseinfo
get_userinfo 0
get_userinfo 1234
get_swapinfo
