#!/bin/bash

fileSize1=$( ls -als $1 | awk '{ print $6 }' )
fileSize2=$( ls -als $2 | awk '{ print $6 }' )

if [ $fileSize1 -gt $fileSize2 ]
then echo "$1"
elif [ $fileSize1 -lt $fileSize2 ]
then echo "$2"
fi
