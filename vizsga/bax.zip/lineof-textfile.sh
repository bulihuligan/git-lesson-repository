#!/bin/bash

sed "$2q;d" $1
