#!/bin/bash

date -d "+$1days"
