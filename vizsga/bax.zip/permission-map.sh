#!/bin/bash

if [[ -f "$1" ]]
then
ls -als $1 | awk '{ print $2 }'
else :
fi
